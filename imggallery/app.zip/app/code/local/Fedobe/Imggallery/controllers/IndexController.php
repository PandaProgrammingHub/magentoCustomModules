<?php

class Fedobe_Imggallery_IndexController extends Mage_Core_Controller_Front_Action{
    function testAction(){
       // echo 'Test !';
    }
}