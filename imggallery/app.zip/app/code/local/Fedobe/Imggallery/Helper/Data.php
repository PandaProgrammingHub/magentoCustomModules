<?php
class Fedobe_Imggallery_Helper_Data extends Mage_Core_Helper_Abstract{
 
}