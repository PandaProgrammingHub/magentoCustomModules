<?php
class Fedobe_Imggallery_Model_Imgdetails extends Mage_Core_Model_Abstract{
    public function _construct() {
        parent::_construct();
        $this->_init('imggallery/imgdetails');
    }
}

