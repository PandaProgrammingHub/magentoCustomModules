<?php
class Fedobe_Manufacturers_Helper_Data extends Mage_Core_Helper_Abstract
{

}
?>