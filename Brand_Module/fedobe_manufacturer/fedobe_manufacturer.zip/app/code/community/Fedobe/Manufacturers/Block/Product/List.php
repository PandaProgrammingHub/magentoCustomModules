<?php
class Fedobe_Manufacturers_Block_Product_List extends Mage_Catalog_Block_Product_List {
    
}
