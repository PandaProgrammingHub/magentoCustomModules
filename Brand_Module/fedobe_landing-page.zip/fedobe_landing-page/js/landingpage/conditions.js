//Here let's set page review url
function reviewlandingpage(url){
//var url = document.getElementById("splash_url_key-note").innerHTML;
window.open(url,'_blank');
}

