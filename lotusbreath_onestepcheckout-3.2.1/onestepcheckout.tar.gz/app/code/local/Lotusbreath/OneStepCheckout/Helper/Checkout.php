<?php
class Lotusbreath_OneStepCheckout_Helper_Checkout extends Mage_Checkout_Helper_Data {

}