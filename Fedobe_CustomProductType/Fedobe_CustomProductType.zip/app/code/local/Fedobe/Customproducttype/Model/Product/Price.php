<?php
class Fedobe_Customproducttype_Model_Product_Price extends Mage_Catalog_Model_Product_Type_Price
{
    /* public function getPrice($product)
    {
        // do your price stuff here.
    }*/
}