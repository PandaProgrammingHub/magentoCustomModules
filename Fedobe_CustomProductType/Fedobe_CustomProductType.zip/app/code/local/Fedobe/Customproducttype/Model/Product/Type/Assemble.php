<?php
class Fedobe_Customproducttype_Model_Product_Type_Assemble extends Mage_Catalog_Model_Product_Type_Abstract
{
 	//you can add whatever you wish in here later on
}