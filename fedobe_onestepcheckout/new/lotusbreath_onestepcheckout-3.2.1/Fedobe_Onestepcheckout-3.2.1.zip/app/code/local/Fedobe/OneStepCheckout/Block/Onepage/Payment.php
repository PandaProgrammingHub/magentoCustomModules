<?php

class Fedobe_OneStepCheckout_Block_Onepage_Payment extends Mage_Checkout_Block_Onepage_Payment {
    
}