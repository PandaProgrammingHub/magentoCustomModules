<?php

class Fedobe_OneStepCheckout_Block_Onepage_Login extends Mage_Checkout_Block_Onepage_Login
{
    protected $_template = 'fedobe/onestepcheckout/onepage/login.phtml';
}