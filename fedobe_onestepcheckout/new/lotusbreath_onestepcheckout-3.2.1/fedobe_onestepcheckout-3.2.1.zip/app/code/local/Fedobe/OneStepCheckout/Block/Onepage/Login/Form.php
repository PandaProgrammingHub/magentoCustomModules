<?php

class Fedobe_OneStepCheckout_Block_Onepage_Login_Form extends Mage_Core_Block_Template
{
    protected $_template = 'fedobe/onestepcheckout/onepage/login.phtml';
}