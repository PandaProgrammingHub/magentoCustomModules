<?php

class Fedobe_OneStepCheckout_Block_Onepage_Shipping_Method extends Mage_Checkout_Block_Onepage_Shipping_Method {
    
}