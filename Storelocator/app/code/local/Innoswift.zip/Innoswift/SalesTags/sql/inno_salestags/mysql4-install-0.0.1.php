<?php

//$this === Mage_Core_Model_Resource_Setup
$installer = $this;

$installer->startSetup();
// any sql b/w these two lines will be executed
$installer->installEntities();

$installer->endSetup();