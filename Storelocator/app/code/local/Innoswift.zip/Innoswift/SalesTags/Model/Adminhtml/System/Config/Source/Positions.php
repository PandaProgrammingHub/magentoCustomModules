<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Positions
 *
 * @author prasad
 */
class Innoswift_SalesTags_Model_Adminhtml_System_Config_Source_Positions {

    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray() {
        return array(
            array('value' => 'tr', 'label' => Mage::helper('adminhtml')->__('Top Right')),
            array('value' => 'tl', 'label' => Mage::helper('adminhtml')->__('Top Left')),
            array('value' => 'br', 'label' => Mage::helper('adminhtml')->__('Bottom Right')),
            array('value' => 'bl', 'label' => Mage::helper('adminhtml')->__('Bottom Left')),
        );
    }

}

