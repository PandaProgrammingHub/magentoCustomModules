<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Tag
 *
 * @author prasad
 */
class Innoswift_SalesTags_Block_Product_List extends Mage_Catalog_Block_Product_List {

    public function getProductTagHtml($product) {
       
            if (Mage::helper('salestags')->isEnableCategoryPage()) {
                $this->setTemplate('salestags/detailed.phtml');
                $this->setProduct($product);
                return $this->toHtml();
            }
        return '';

//    }
    }

    public function getTagStyle() {
        if ($_place = Mage::helper('salestags')->getTagPlace()) {
            $_place = str_replace(' ', '-', strtolower($_place));
            return $_place;
        }
        return '';
    }

}

