<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of View
 *
 * @author prasad
 */
class Innoswift_SalesTags_Block_Product_View extends Mage_Catalog_Block_Product_View {

    public function getProductTagHtml($product) {

        if (Mage::helper('salestags')->isEnableProductPage()) {
            $this->setTemplate('salestags/detailed.phtml');
            $this->setProduct($product);
            return $this->toHtml();
        }
        return '';

//    }
    }

    public function getTagStyle() {
        if ($_place = Mage::helper('salestags')->getTagPlace()) {
            $_place = str_replace(' ', '-', strtolower($_place));
            return $_place;
        }
        return '';
    }

}

