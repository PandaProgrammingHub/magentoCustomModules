<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Data
 *
 * @author prasad
 */
class Innoswift_SalesTags_Helper_Data extends Mage_Core_Helper_Abstract {

    /**
     *
     * @return type 
     */
    public function isEnabled() {
        $_isEnabled = trim(Mage::getStoreConfig('innoswift_salestags/salestags_enable/enabled'));
        if ($_isEnabled) {
            return true;
        }
        return false;
    }

    public function isEnableProductPage() {
        if ($this->isEnabled()) {
            $_enable = trim(Mage::getStoreConfig('innoswift_salestags/salestags_settings/sales_product'));
            if ($_enable) {
                return true;
            }
        }
        return false;
    }

    public function isEnableCategoryPage() {
        if ($this->isEnabled()) {
            $_enable = trim(Mage::getStoreConfig('innoswift_salestags/salestags_settings/sales_category'));
            if ($_enable) {
                return true;
            }
        }
        return false;
    }

    public function getTagPlace() {
        if ($this->isEnabled()) {
            $_place = trim(Mage::getStoreConfig('innoswift_salestags/salestags_settings/sales_tags_position'));
            return $_place;
        }
        return false;
    }

}

