<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Payjunction
 *
 * @author shashi
 */
class Innoswift_Payjunction_Model_Api {

    //put your code here

    private $_userName = "";
    private $_password = "";
    private $_client;
    private $_url = '';
    
    const RESPONSE_APPROVED_00 = "00";
    const RESPONSE_APPROVED_85 = "85";

    const RESPONSE_DECLINED = "DT";
    const GATEWAY_ERROR = "11";
    const REQUEST_TYPE_AUTH_CAPTURE = 'AUTHORIZATION_CAPTURE';
    const REQUEST_TYPE_AUTH_ONLY = 'AUTHORIZATION';

    const REQUEST_TYPE_UPDATE_POSTURE = 'update';
    const REQUEST_TYPE_CREDIT = 'CREDIT';

    public function __construct() {
        $this->_userName = mage::getStoreConfig("payment/payjunction/login");
        $this->_password = mage::getStoreConfig("payment/payjunction/password");
        $_url = mage::getStoreConfig("payment/payjunction/test");
        $this->_url = $_url;
        $this->_client = new Zend_Http_Client($_url);
        $_config = array(
            'adapter' => 'Zend_Http_Client_Adapter_Curl',
            'curloptions' => array(
                CURLOPT_FOLLOWLOCATION => 1,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_FOLLOWLOCATION => 0,
                CURLOPT_RETURNTRANSFER => 1,
                CURLOPT_SSL_VERIFYPEER => 1
            )
        );

        $this->_client->setParameterPost('dc_logon', $this->_userName);
        $this->_client->setParameterPost('dc_password', $this->_password);
        $this->_client->setParameterPost("dc_version", "1.2");


        $this->_client->setConfig($_config);
    }

    /**
     * Process the transaction
     */
    public function process() {

        try {

            $_response = $this->_client->request(Zend_Http_Client::POST);
            $content = explode(chr(28), $_response->getBody()); // The ASCII field seperator character is the delimiter

            $_result = array();
            foreach ($content as $key_value) {
                list ($key, $value) = explode("=", $key_value);
                $_result[$key] = $value;
            }
            //return results of request
            $_request = $this->_client->getLastRequest();

            //start debugging if debugging is enabled
            if ($_debug = mage::getStoreConfig("payment/payjunction/debug")) {

                $this->debug("Request:{$this->_client->getUri()}");
                $this->debug($_result);
            }
        } catch (Zend_Http_Client_Exception $e) {
            mage::log($e->getMessage());
            mage::logException($e);
            throw new Mage_Payment_Exception("Payjunction gateway error!", self::GATEWAY_ERROR);
        }

        $_successRes = array(self::RESPONSE_APPROVED_00,self::RESPONSE_APPROVED_85);
        if (!in_array($_result['dc_response_code'],$_successRes)) {
            throw new Mage_Payment_Exception("Transaction has been delined!", Innoswift_Payjunction_Model_Method::STATUS_DECLINED);
        }

        return $_result;
    }

    public function authorize($payment, $amount) {
        $this->setCcData($payment, $amount);
        $this->_client->setParameterPost('dc_transaction_type', self::REQUEST_TYPE_AUTH_ONLY);
        return $this->process();
    }

    public function capture($payment, $amount) {
        $this->setCcData($payment, $amount);
        $this->_client->setParameterPost('dc_transaction_type', self::REQUEST_TYPE_AUTH_CAPTURE);
        return $this->process();
    }

    public function refund($payment, $amount) {
        $this->_client->setParameterPost('dc_transaction_amount', $amount);
        $this->_client->setParameterPost('dc_transaction_id', $payment->getLastTransId());
        $this->_client->setParameterPost('dc_transaction_type', self::REQUEST_TYPE_CREDIT);
        return $this->process();
    }

    public function updatePosture($payment, $newPosture) {
        $this->_client->setParameterPost('dc_posture', "{$newPosture}");
        $this->_client->setParameterPost('dc_transaction_type', self::REQUEST_TYPE_UPDATE_POSTURE);
        $this->_client->setParameterPost('dc_transaction_id', $payment->getLastTransId());
        return $this->process();
    }

    public function setCcData($payment, $amount) {

        $_billingAddress = $payment->getOrder()->getBillingAddress();

        $_ccName = trim($payment->getCcOwner());
        $_ccNum = trim($payment->getCcNumber());

        $this->_client->setParameterPost('dc_first_name', "{$_billingAddress->getFirstname()}");
        $this->_client->setParameterPost('dc_last_name', "{$_billingAddress->getLastname()}");

        //$this->_client->setParameterPost('dc_card_name', "{$_ccName}");
        $this->_client->setParameterPost('dc_verification_number', "{$payment->getCcCid()}");
        $this->_client->setParameterPost('dc_expiration_year', "{$payment->getCcExpYear()}");
        $this->_client->setParameterPost('dc_expiration_month', "{$payment->getCcExpMonth()}");
        
//        $this->_client->setParameterPost('dc_shipping_amount',"{$payment->getOrder()->getShippingAmount()}"); 
//        $this->_client->setParameterPost('dc_tax_amount',"{$payment->getOrder()->getTaxAmount()}"); 

        $this->_client->setParameterPost('dc_transaction_amount', $amount);

        if ($this->isTest()) {
            $this->_client->setParameterPost('dc_transaction_amount', $amount + (rand(10, 100) / 100));
        }

        $this->_client->setParameterPost('dc_number', "{$_ccNum}");
    }

    public function isTest() {
        if ($this->_url == Innoswift_Payjunction_Model_Config_Mode::SANDBOX_URL) {
            return true;
        }

        return false;
    }

    public function debug($debugData) {
        Mage::getModel('core/log_adapter', 'payjunction.log')->log($debugData);
    }

}