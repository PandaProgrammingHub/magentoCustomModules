<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Mode
 *
 * @author shashi
 */
class Innoswift_Payjunction_Model_Config_Mode{
    //put your code here
    
    const LIVE_URL = "https://www.payjunction.com/quick_link";
    const SANDBOX_URL = "https://www.payjunctionlabs.com/quick_link";
      /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return array(
            array('value' => self::SANDBOX_URL, 'label'=>Mage::helper('adminhtml')->__('Yes')),
            array('value' => self::LIVE_URL, 'label'=>Mage::helper('adminhtml')->__('No')),
        );
    }
}
