<?php

/**
 * Description of Method
 *
 * @author shashi
 */
class Innoswift_Payjunction_Model_Method extends Mage_Payment_Model_Method_Cc {

    //put your code here
    protected $_isGateway = true;
    protected $_canAuthorize = true;
    protected $_canCapture = true;
    protected $_canCapturePartial = false;
    protected $_canRefund = true;
    protected $_canRefundInvoicePartial = true;
    protected $_canVoid = true;
    protected $_canUseInternal = true;
    protected $_canUseCheckout = true;
    protected $_canUseForMultishipping = true;
    protected $_canSaveCc = false;
    protected $_canFetchTransactionInfo = false;
    protected $_canReviewPayment = true;
    protected $_code = "payjunction";
    protected $_allowCurrencyCode = array('USD');
    protected $_formBlockType = 'payment/form_cc';
    protected $_infoBlockType = 'payment/info_cc';
    protected $_api;

    const POSTURE_CAPTURE = "capture";
    const POSTURE_VOID = "void";

    public function __construct($params = array()) {
        $_api = mage::getModel('payjunction/api');
        /* @var $_api Innoswift_Payjunction_Model_Api */
        $this->_api = $_api;
    }

    /**
     * this method is called if we are just authorising
     * a transaction
     */
    public function authorize(Varien_Object $payment, $amount) {
        if ($amount <= 0) {
            Mage::throwException(Mage::helper('paygate')->__('Invalid amount for authorization.'));
        }
        parent::authorize($payment, $amount);

        $this->_processOrder($payment, $amount, self::ACTION_AUTHORIZE);

        return $this;
    }

    /**
     * this method is called if we are authorising AND
     * capturing a transaction
     */
    public function capture(Varien_Object $payment, $amount) {
        if ($amount <= 0) {
            Mage::throwException(Mage::helper('paygate')->__('Invalid amount for capture.'));
        }
        parent::capture($payment, $amount);

        $this->_processOrder($payment, $amount, self::ACTION_AUTHORIZE_CAPTURE);
        return $this;
    }

    /**
     * Refund the amount with transaction id
     *
     * @param Mage_Payment_Model_Info $payment
     * @param decimal $amount
     * @return Mage_Paygate_Model_Authorizenet
     * @throws Mage_Core_Exception
     */
    public function refund(Varien_Object $payment, $requestedAmount) {

        parent::refund($payment, $requestedAmount);
        $this->_processOrder($payment, $requestedAmount, "REFUND");
        return $this;
    }

    private function _processOrder(Varien_Object $payment, $amount, $type) {
        try {
            switch ($type) {
                case self::ACTION_AUTHORIZE:

                    $_response = $this->_api->authorize($payment, $amount);
                    $this->setTransactionInfo($payment, $_response, $amount);
                    $payment->setIsTransactionClosed(0);

                    break;
                case self::ACTION_AUTHORIZE_CAPTURE:
                    if (!$payment->getLastTransId()) {
                        $_response = $this->_api->capture($payment, $amount);
                        $this->setTransactionInfo($payment, $_response, $amount);
                    } else {
                        $_response = $this->_api->updatePosture($payment, self::POSTURE_CAPTURE);
                    }

                    break;

                case "REFUND" :
                    $_response = $this->_api->refund($payment, $amount);
                    break;
            }
        } catch (Mage_Payment_Exception $e) {
            if ($e->getCode() == self::STATUS_DECLINED) {
                $payment->setStatus(self::STATUS_DECLINED);
                Mage::throwException(
                        Mage::helper('payment')->__('Transaction declined.')
                );
            } else {
                throw new Mage_Payment_Exception("payment failed gateway issue!");
            }
        }
    }

    public function setTransactionInfo($payment, $response, $amount) {

        $this->setStore($payment->getOrder()->getStoreId());
        $payment->setStatus(self::STATUS_APPROVED);
        $payment->setAmount($amount);
        $payment->setTransactionId($response['dc_transaction_id']);
    }

    /**
     * called if voiding a payment
     */
    public function void(Varien_Object $payment) {
        parent::void($payment);
        $_response = $this->_api->updatePosture($payment, self::POSTURE_VOID);
        return $this;
    }

    /**
     * Check capture availability
     *
     * @return bool
     */
    public function canCapture() {
        return true;
    }

    /**
     * Check method for processing with base currency
     *
     * @param string $currencyCode
     * @return boolean
     */
    public function canUseForCurrency($currencyCode) {
        if (in_array($currencyCode, $this->_allowCurrencyCode)) {
            return true;
        }
        return false;
    }

    public function isAvailable($quote = null) {
        return parent::isAvailable($quote);
    }

}

