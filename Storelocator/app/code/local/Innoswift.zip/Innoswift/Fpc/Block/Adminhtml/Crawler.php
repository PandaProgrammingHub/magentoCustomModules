<?php

class Innoswift_Fpc_Block_Adminhtml_Crawler extends Mage_Adminhtml_Block_System_Config_Form_Field {
    const PROGRESS_WIDTH = "800";

    /**
     * Get the button and scripts contents
     *
     * @param Varien_Data_Form_Element_Abstract $element
     * @return string
     */
    protected function _getElementHtml(Varien_Data_Form_Element_Abstract $element) {

        $lastRunAt = mage::app()->loadCache(Innoswift_Fpc_Model_Crawler::CRAWLER_LAST_RUN) . " GMT";
        $ajaxUrlForCache = $this->getUrl('innoswiftfpc/adminhtml_service/gencache');
        $ajaxUrlForProgress = $this->getUrl('innoswiftfpc/adminhtml_service/getprogress');
        $countUrlsToCache = mage::getModel('innoswiftfpc/url')->getCollection()->getSize();

        $progressWidth = self::PROGRESS_WIDTH . "px";
        $progress = self::PROGRESS_WIDTH;

        $html = <<<HTML
         
        $lastRunAt
            <br/><br/>
        
        Urls to Cache: <span id="to_cache_count" style="font-weight:bold;color:green;">$countUrlsToCache</span>
        <br/>
            
        <script type="text/javascript">
            function genCache() {
        
                var uncached = $('uncached_checkbox').getValue();
                 
                new Ajax.Request('$ajaxUrlForCache', {
                    method: 'get',
                    parameters: {uncached: uncached},
                    onSuccess: function(response) {
                    }
                });
             
            }
        
        
         function updateProgress() {

                new Ajax.Request('$ajaxUrlForProgress', {
                    method: 'get',
                    onSuccess: function(response) {
        
                     var jsonResponse = response.responseText.evalJSON(true);
                     var progress = jsonResponse.progress_width;
        
                       $('progress').setStyle({width: progress+"px" });
                       $('to_cache_count').update(jsonResponse.urls_left);
                        if(progress != $progress){  
                          var timeout = 6000;
                          var uncached = $('uncached_checkbox').getValue();
                          if(uncached){
                             timeout=500;
                          } 
                          setTimeout("updateProgress();",timeout);
                        }
                    }
                });
            }
        
        function startCaching(){
          
          genCache();
          setTimeout("updateProgress();",5000);
        }
        
       </script>
        
          <style type="text/css">
        .rounded-corners {
                 -moz-border-radius: 3px;
                -webkit-border-radius: 3px;
                -khtml-border-radius: 3px;
                border-radius: 3px;
            }
        </style>
         
            <div id="progress_bar" class="rounded-corners" style="background:#E4F6F8;width:$progressWidth;height:7px;border:solid silver 1px;">
               <div id="progress" class="rounded-corners"  style="width:0px;height:7px;background:#31B96E;"></div>
            </div>
            <br/>
            <br/>
            <input type="checkbox" name="uncached" id="uncached_checkbox" value="1" checked="checked" /> UN-CACHED URLS ONLY <br/> <span style="color:red;">Note:
            Uncheck if you want to rebuild page cache for all urls. [ Slow ]</span><br/><br/>
            <button type="button" id="generate_cache" name="generate_cache" onclick="startCaching();return false;">Generate Page Cache</button>
HTML;

        return $html;
    }

}
