<?php

class Innoswift_Fpc_Block_Product_Viewed extends Mage_Reports_Block_Product_Viewed {

    public function getProductIds() {
        //if page caching is enabled used cookies insted of the database
        if (Innoswift_Fpc_Model_Processor_Default::$CAN_CACHE) {
            return explode(',', $_COOKIE['viewed_ids']);
        }else{
            parent::getProductIds();
        }
    }

}
