<?php

$installer = $this;

$installer->startSetup();

$installer->run("

DROP TABLE IF EXISTS {$this->getTable('innoswiftfpc/url')};
CREATE TABLE {$this->getTable('innoswiftfpc/url')} (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `url_hash` varchar(33),
  `url` varchar(200),
  `crawler_flag` bool, 
  PRIMARY KEY (`id`),
  KEY `IDX_URL_HASH` (`url_hash`),
  KEY `IDX_CRAWLER_FLAG` (`crawler_flag`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1
    
");

$installer->endSetup();
