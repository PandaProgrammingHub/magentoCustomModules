<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Innoswift_Fpc_Model_Processor_Cms extends Innoswift_Fpc_Model_Processor_Default {
    const PAGE_TYPE = "cms";

    protected function onInit() {
        parent::onInit();
        Mage::register('page_type', self::PAGE_TYPE);
    }

    protected function getHtmlDataObject() {

        $htmlObject = parent::getHtmlDataObject();
        //registering the categoty id to the cache
        $page_id = mage::app()->getFrontController()->getRequest()->get('page_id');

        if (!$page_id) {
            //hope pages we have to find the page ids the hard way
            $page = Mage::getSingleton('cms/page');
            $page_id = Mage::getStoreConfig(Mage_Cms_Helper_Page::XML_PATH_HOME_PAGE);
            $page->setStoreId(Mage::app()->getStore()->getId());
            $page->load($page_id);
            $page_id =  $page->getPageId();
        }
        $htmlObject->setPageId($page_id);

        return $htmlObject;
    }

    protected function getItemCacheTag($htmlObject) {
        $cmsPageCacheTag = trim(Mage_Cms_Model_Page::CACHE_TAG . "_" . $htmlObject->getPageId());
        return $cmsPageCacheTag;
    }

    protected function getPageUrlCacheKey() {
        $key = parent::getPageUrlCacheKey();
        return self::FULL_PAGE_CACHE_PREFIX . self::PAGE_TYPE . $key;
    }

}
