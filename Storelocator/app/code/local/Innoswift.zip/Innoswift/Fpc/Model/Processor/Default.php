<?php

/**
 * Page cache processor default
 * author shashi
 */
class Innoswift_Fpc_Model_Processor_Default {
    /**
     * cache life time for each page set to 7 days
     */
    const PAGE_CACHE_LIFE_TIME = 604800;
    /**
     * the cache ttl for user specific blocks
     */
    const USER_SPECIFIC_BLOCK_CACHE_TTL = 800;
    const URL_DEPTH_TO_CACHE = 4;
    const DYNAMIC_BLOCK_CACHE_KEY = "DYNAMIC_BLOCK_CACHE_KEY";
    const FULL_PAGE_CACHE_PREFIX = "_page_";
    /* page caching settting on the admin */
    const CACHE_SETTINGS = "full_page_caching";
    protected static $VALID_ROUTES = array('catalog_product_view', 'catalog_category_view', 'cms_page_view', 'cms_index_index');
    /**
     * full page cache tag
     */
    const PAGE_CACHE_TAG = "fpc";
    /**
     * cahe tag for punched blocks tat are dynamic
     */
    const USER_BLOCK_CACHE_TAG = "user_blocks_cache";
    const SESSION_CACHE_TAG = "SESSION_CACHE_TAG";
    /**
     * flag to say if caching is enabled
     */
    public static $CAN_CACHE = true;
    public static $DONT_PROCESS_DEBUG = false;
    /* route key from where the caching is callled */
    private $_route_key = null;
    const PAGE_TYPE = "DEFAULT";

    protected static $DYNAMIC_BLOCK_UPDATES = array();
    protected static $HTML_CACHE_OBJECT = null;
    protected static $URL_TO_CACHE;
    /**
     * Innoswift_Fpc_Helper_Data
     */
    protected $_helper;
    private $_dynamicBlockNames;
    private $_dynamicBlockNamesToCache;

    public function __construct() {

        $this->_helper = new Innoswift_Fpc_Helper_Data();
        $this->onInit();
    }

    /**
     * to check if page caching can be performed for the request
     * @return null
     */
    protected function onInit() {

        $this->canProcessUrl(); //this tests if we can cache this url
        //cheking if page caching is enabled in admin
        if (!Mage::app()->useCache(self::CACHE_SETTINGS)) {
            self::$CAN_CACHE = false; //disabling cache
            return $this;
        }
        //disable page caching if page has messages
        $hasMessages = sizeof(Mage::getSingleton('core/session')->getMessages()->getItems());
        if ($hasMessages) {
            self::$CAN_CACHE = false;
        }
        //here we can write conditions for disabling page cache
        //stub method will be further implemented by children if needed
    }

    /**
     * matof to save the html and other metadata for the request url
     * @return type null
     */
    public function saveHtmlToCache($event) {

        if (!self::$CAN_CACHE) {
            return;
        }
        $updatesXml = $this->getProcessedDynamicBlocksXml();
        $response = $event->getControllerAction()->getResponse();
        $body = $response->getBody();
        $cacheKey = $this->getPageUrlCacheKey();

        $dataToStore = $this->getHtmlDataObject()
                ->setDynamicLayoutXml($updatesXml)
                ->setHtmlBody($body);
        self::$HTML_CACHE_OBJECT = $dataToStore;
        //saving the html with plaholders to cache
        Mage::app()->saveCache(
                gzcompress(serialize($dataToStore)), $cacheKey, $this->getPageCacheTags($dataToStore), $this->_helper->getPageCacheTTL()
        );

        if ($this->shouldRegenerateCache()) {
            return;
        }
        //here we log the url for the crawer to reseed the page cache
        $url = mage::getModel('innoswiftfpc/url');
        $urlCollection = $url->getCollection();
        $urlHash = md5(self::$URL_TO_CACHE);
        $urlCollection->addFieldToFilter('url_hash', $urlHash);
        $isUrlLogged = $urlCollection->getSize();
        if (!$isUrlLogged) {
            $url->setUrlHash($urlHash);
            $url->setUrl(self::$URL_TO_CACHE);
            $url->save();
        }
        return;
    }

    protected function getPageCacheTags($dataToStore) {
        return array(self::PAGE_CACHE_TAG, $this->getItemCacheTag($dataToStore));
    }

    /**
     * builds the dynamic layout xml for the request
     * @return  string
     */
    protected function getProcessedDynamicBlocksXml() {

        $updateXml = "";
        foreach (self::$DYNAMIC_BLOCK_UPDATES as $blockName => $blockObject) {
            $blockXml = $blockObject->getXml();
            $updateXml.= $blockXml;
        }
        return $updateXml;
    }

    /**
     * metod to punch holes in the cached html
     * @param type $event
     * @return type 
     */
    public function replaceWithPlaceholder($event) {

        if (mage::registry('PLACEHOLDER_LAYOUT') || !self::$CAN_CACHE) {
            return;
        }
        $layout = $event->getBlock()->getLayout();
        $transport = $event->getTransport();
        $block = $event->getBlock();
        $thisBlockName = $block->getNameInLayout();
        $thisBlockRealName = $block->getBlockId();

        //if the block is defined as dynamic from admin
        $isBlockDynamic = in_array($thisBlockName, $this->_dynamicBlockNames);
        //this is to chec admin added blocks for cms pages
        if(in_array($thisBlockRealName, $this->_dynamicBlockNames)){
            $isBlockDynamic = true;
            
             if(!$thisBlockRealName){
                $thisBlockRealName = $block->getName();
            }
            $thisBlockName = $thisBlockRealName;
        }

        if ($block->getDynamicBlock() || $isBlockDynamic) {

            $xquery = "//*[@name='$thisBlockName']";
            $nodes = $layout->getXpath($xquery);

            $blockXml = "";
            foreach ($nodes as $node) {
                $blockXml.=$node->asXML();
            }
            
            if(!$blockXml){
                $name = $type = $template = "";
                $name = $thisBlockName;
                $type = $block->getType();
                $template = $block->getTemplate();
                $blockXml = "<block name='$name' type='$type' template='$template' />";
            }
            $xmlforBlock = new Varien_Object();
            $xmlforBlock->setXml($blockXml);
            $xmlforBlock->setBlock($block);

            self::$DYNAMIC_BLOCK_UPDATES[$thisBlockName] = $xmlforBlock;
            $transport->setHtml('{{' . $thisBlockName . '}}');
        }
    }

    /**
     * method to fetch the cache and send it back to the client
     * @param type $event
     * @return type 
     */
    public function returnCache($event) {

        if (!self::$CAN_CACHE) {
            return;
        }

        $cacheKey = $this->getPageUrlCacheKey();
        $htmlObject = Mage::app()->loadCache($cacheKey);
        if (!$htmlObject || $this->shouldRegenerateCache()) {
            //if page cache is enabled disable block cache
            Mage::app()->getCacheInstance()->banUse(Mage_Core_Block_Abstract::CACHE_GROUP);
            return;
        }
        $htmlObject = unserialize(gzuncompress($htmlObject));
        $this->returnCacheBefore($htmlObject);
        self::$HTML_CACHE_OBJECT = $htmlObject;
        $event->getControllerAction()->getResponse()->setBody($htmlObject->getHtmlBody())->sendResponse();
        exit();
    }

    protected function shouldRegenerateCache() {
        //if its the crawler cralling ths site to recache
        if (isset($_COOKIE['fpc_cache_crawler'])) {
            return true;
        }
        //if no cache get parameter is paseed 
        if (isset($_GET['no_cache'])) {
            return true;
        }
        return false;
    }

    /**
     * fill the holes with dynamic blocks on the fly and cache them when we can
     * @param type $event
     * @return type 
     */
    public function processContentAndSend($event) {

        if (self::$DONT_PROCESS_DEBUG) {
            return;
        }
        if (!self::$CAN_CACHE) {
            //dele user caches for all other urls tat cant be cached
            $this->clearUserSpecificCache();
            return;
        }
        $responseBody = $event->getResponse()->getBody();

        preg_match_all('/\{\{(.*)\}\}/', $responseBody, $matches);
        $matches['to_replace'] = $matches[0];
        $matches['block_names'] = $matches[1];

        if (!sizeof($matches['block_names'])) {
            return; //if there are no dynamic blocks on the page
        }
        $layout = new Mage_Core_Model_Layout();
        $updates = self::$HTML_CACHE_OBJECT;
        //replaceing the seesion key for user blocks
        $updatesXml = $updates->getDynamicLayoutXml();
        $xml = $layout->getUpdate()->addUpdate($updatesXml);

        //this flad disables place holder replacement of dynamic blocks 
        mage::register("PLACEHOLDER_LAYOUT", true);
        $layout->generateXml()->generateBlocks();

        foreach ($matches['to_replace'] as $id => $token) {

            $blockName = $matches['block_names'][$id];
            $block = $layout->getBlock($blockName);
            if(!$block){
                continue;
            }
            $block = $this->addBlockCacheInfo($block, $blockName);
            $toReplace = $block->toHtml();
            $responseBody = str_replace($token, $toReplace, $responseBody); ///plugging the hold with content
        }
        //$crawler = new Innoswift_Fpc_Model_Crawler();
        //$crawler->crawl();

        $event->getResponse()->setBody($responseBody);
        return;
    }

    protected function addBlockCacheInfo($block, $name) {
        $canCacheBlock = false;
        $dynamicBlocksToCache = $this->_dynamicBlockNamesToCache;
        //checking if we can cache this block for the user
        $canCacheBlock = in_array($name, $dynamicBlocksToCache);
        
        if(!$canCacheBlock){
            return $block;
        }
        //add cache configuration to the block if neverCache is false
        if (($block->getCacheThis() || $canCacheBlock) && isset($_COOKIE['frontend'])) {

            $block->setCacheLifetime(self::USER_SPECIFIC_BLOCK_CACHE_TTL);
            $block->setCacheTags(array(self::USER_BLOCK_CACHE_TAG, $_COOKIE['frontend']));
            $cacheKey = $_COOKIE['frontend'] . $name . $this->_getRouteKey().Mage::app()->getStore()->getId();  
            $block->setCacheKey($cacheKey);
        }
        return $block;
    }

    /**
     * method to generate cache key based on url and type of user if he is logged in
     * @return string 
     */
    protected function getPageUrlCacheKey() {
        $_url = false;
        if (isset($_SERVER['HTTP_HOST'])) {
            $_url = $_SERVER['HTTP_HOST'];
        } elseif (isset($_SERVER['SERVER_NAME'])) {
            $_url = $_SERVER['SERVER_NAME'];
        }
        if ($_url) {
            if (isset($_SERVER['REQUEST_URI'])) {
                $_url.= $_SERVER['REQUEST_URI'];
            } elseif (!empty($_SERVER['IIS_WasUrlRewritten']) && !empty($_SERVER['UNENCODED_URL'])) {
                $_url.= $_SERVER['UNENCODED_URL'];
            } elseif (isset($_SERVER['ORIG_PATH_INFO'])) {
                $_url.= $_SERVER['ORIG_PATH_INFO'];
                if (!empty($_SERVER['QUERY_STRING'])) {
                    $_url.= $_SERVER['QUERY_STRING'];
                }
            }
        }
        self::$URL_TO_CACHE = $_url;
        $customer = mage::getModel("customer/session")->getCustomer();
        $group_id = $customer->getGroupId();
        //cache key has url and customer group
        $cacheKey = '_' . md5($_url) . "_grp_$group_id";
        return $cacheKey; //returning the cache key
    }

    /**
     * method to generate the route key for the request "catalog_product_view" etc...
     * @return string 
     */
    protected function _getRouteKey() {

        if ($this->_route_key) {
            return $this->_route_key;
        }
        $request = mage::App()->getFrontController()->getRequest();
        $_moduleName = $request->getModuleName();
        $_controllerName = $request->getControllerName();
        $_actionName = $request->getActionName();
        $_hashRequest = $_moduleName . '_' . $_controllerName . '_' . $_actionName;
        $this->_route_key = $_hashRequest;
        return $this->_route_key;
    }

    /**
     * this gerated the simple object to be cached for a request
     * @return Varien_Object 
     */
    protected function getHtmlDataObject() {
        $htmlObject = new Varien_Object();
        return $htmlObject;
    }

    public function clearUserSpecificCache() {
        if(isset($_COOKIE['frontend'])){
           mage::app()->cleanCache(array($_COOKIE['frontend']));
        }
    }

    protected function returnCacheBefore($htmlObject) {
        //will be implemented by children if needed
    }

    protected function getItemCacheTag($htmlObject) {
        //will be imo=plmented by children to enable cache refresh on each item
    }

    protected function canProcessUrl() {
        if (!in_array($this->_getRouteKey(), self::$VALID_ROUTES)) {
            self::$CAN_CACHE = false;
        }

        if (sizeof($_GET) > $this->_helper->getUrlDepth()) {
            self::$CAN_CACHE = false;
        }
        //getting the dynamic blovk info
        $this->_dynamicBlockNames = $this->_helper->getDynamicBlockNames();
        $this->_dynamicBlockNamesToCache = $this->_helper->getDynamicBlockNamesToCache();

    }

    /**
     * Invalidate  page cache
     */
    public function invalidateCache() {
        Mage::app()->getCacheInstance()->invalidateType(self::CACHE_SETTINGS);
    }

    /**
     * Clean full page cache
     */
    public function clearCache() {
        Mage::app()->cleanCache(self::PAGE_CACHE_TAG);
        Mage::app()->cleanCache(self::USER_BLOCK_CACHE_TAG);
    }

}

