<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Innoswift_Fpc_Model_Processor_Product extends Innoswift_Fpc_Model_Processor_Default {
    
     const PAGE_TYPE = "prod";

    protected function onInit() {
        parent::onInit();
        Mage::register('page_type', self::PAGE_TYPE);
        //disable page caching if page has error messages
        $hasMessages = sizeof(Mage::getSingleton('checkout/session')->getMessages()->getItems());
        if ($hasMessages) {
            self::$CAN_CACHE = false;
        }
    }

    protected function returnCacheBefore($htmlObject) {
        parent::returnCacheBefore($htmlObject);
        //setting the cokkie for viewed products
        $viewedProdIds = false;
     
        if ($viewedProdIds = mage::getModel('core/cookie')->get('viewed_ids')) {

            $isLogged=strpos($viewedProdIds, $htmlObject->getProductId());
            if ($isLogged!==false) {
                return;
            }
            $viewedProdIds = $htmlObject->getProductId() . "," . $viewedProdIds;
            mage::getModel('core/cookie')->set('viewed_ids', $viewedProdIds);
        } else {
            mage::getModel('core/cookie')->set('viewed_ids', $htmlObject->getProductId());
        }
   
          return;
    }
    
    protected function getPageUrlCacheKey(){
       $key = parent::getPageUrlCacheKey();
       return self::FULL_PAGE_CACHE_PREFIX.self::PAGE_TYPE.$key;
    }

    protected function getHtmlDataObject() {

        $htmlObject = parent::getHtmlDataObject();
        //registering the product id
        $htmlObject->setProductId(Mage::registry('current_product')->getId());

        return $htmlObject;
    }
       
    protected function getItemCacheTag($htmlObject) {
        $prodCacheTag = trim(Mage_Catalog_Model_Product::CACHE_TAG ."_".$htmlObject->getProductId());
        return $prodCacheTag;
    }

}
