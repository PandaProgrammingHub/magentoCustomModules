<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Innoswift_Fpc_Model_Mysql4_Url_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract {

    protected function _construct() {
        $this->_init('innoswiftfpc/url', 'id');
    }

}
