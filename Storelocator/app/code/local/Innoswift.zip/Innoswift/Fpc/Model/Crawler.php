<?php

class Innoswift_Fpc_Model_Crawler extends Mage_Core_Model_Abstract {
    const CRAWLER_LAST_RUN = "CRAWLER_LAST_RUN";

    /**
     * this will crawl all previoously cached urls
     */
    public function crawl($onlyUnCached=false) {

        $client = new Zend_Http_Client();
        $client->setConfig(array(
            'maxredirects' => 0,
            'timeout' => 1000,
            'keepalive' => true
        ));

        if (!$onlyUnCached) {
            //this tell the site to not return cached pages
            $client->setCookie('fpc_cache_crawler', '1');
        }

        $urlCollection = mage::getModel('innoswiftfpc/url')->getCollection();
        $urlsToCache = $urlCollection->addFieldToFilter('crawler_flag', 1);
        $_flaggedUrl = false;
        foreach ($urlsToCache as $_flaggedUrl) {
            
        }
        if ($_flaggedUrl) {
            //this means crawler was stopped in the middle
            $urlsToCache = mage::getModel('innoswiftfpc/url')->getCollection();
            $urlsToCache->addFieldToFilter('id', array('gteq' => $_flaggedUrl->getId()));
        } else {
            //this means crawler has to start from the beginning
            $urlsToCache = mage::getModel('innoswiftfpc/url')->getCollection();
        }
        $prevUrl = false;
        $urlCount = 0;
        $countToCache = $urlsToCache->getSize();
        //crawling the url to recache them
        foreach ($urlsToCache as $url) {

            $urlToRecache = trim('http://' . $url->getUrl());
            $client->setUri($urlToRecache);
            $response = $client->request('GET');

            if (!in_array($response->getStatus(), array("200", "503"))) {
                $url->isDeleted(true);
            }

            //marking the url as crawled
            $url->setCrawlerFlag(1);
            $url->save();
            if ($prevUrl) {
                $prevUrl->setCrawlerFlag(0);
                $prevUrl->save();
            }
            $prevUrl = $url;
            $urlCount++;
            //if we reach the end we set it to false to show one full crawl
            if ($urlCount == $countToCache) {
                $url->setCrawlerFlag(0);
                $url->save();
                $today = date("F j, Y, g:i a");
                //logging the cron fishihed flag
                mage::app()->saveCache($today, self::CRAWLER_LAST_RUN, array(), 864000);
            }
        }
    }

}
