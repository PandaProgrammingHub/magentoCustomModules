<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Innoswift_Fpc_Model_Processor_Category extends Innoswift_Fpc_Model_Processor_Default {

    const PAGE_TYPE = "catig";

    protected function onInit() {
        parent::onInit();
        Mage::register('page_type', self::PAGE_TYPE);
    }

    protected function getHtmlDataObject() {

        $htmlObject = parent::getHtmlDataObject();
        //registering the categoty id to the cache
        $htmlObject->setCategoryId(Mage::registry('current_category')->getId());

        return $htmlObject;
    }

    protected function getItemCacheTag($htmlObject) {
        $prodCacheTag = trim(Mage_Catalog_Model_Category::CACHE_TAG . "_" . $htmlObject->getCategoryId());
        return $prodCacheTag;
    }

    protected function getPageUrlCacheKey() {
        $key = parent::getPageUrlCacheKey();
        return self::FULL_PAGE_CACHE_PREFIX . self::PAGE_TYPE . $key;
    }

    /**
     * generated the cache key for each dymamic block in the layout
     * @param type $block_name
     * @return string 
     */
    public static function getBlockXmlCacheKeyCatig($block_name) {
        $keyUrl = parent::getPageUrlCacheKey();
        $key = self::FULL_PAGE_CACHE_PREFIX . "block_xml_catig" . $keyUrl . "_" . $block_name;
        return $key;
    }

}
