<?php

class Innoswift_Fpc_Helper_Data extends Mage_Core_Helper_Abstract {

    public function getDynamicBlockNames() {

        $blocks = trim(Mage::getStoreConfig('page_cache_fpc/dynamic_layout_settings/dynamic_block_names'));
        if (!trim($blocks)) {
            return array();
        }
        $blocks = explode("\n", $blocks);

        $names = array();
        foreach ($blocks as $name) {
            $names[] = trim($name);
        }

        return $names;
    }

    public function getDynamicBlockNamesToCache() {

        $blocks = trim(Mage::getStoreConfig('page_cache_fpc/dynamic_layout_settings/dynamic_block_names_to_cache'));
        if (!trim($blocks)) {
            return array();
        }

        $blocks = explode("\n", $blocks);


        $names = array();
        foreach ($blocks as $name) {
            $names[] = trim($name);
        }

        return $names;
    }

    public function getPageCacheTTL() {
        $ttl = Mage::getStoreConfig('page_cache_fpc/settings/cache_ttl');
        $ttl = floatval($ttl);

        if (is_float($ttl) && $ttl > 0) {
            //converting hours to seconds
            return $ttl * 60 * 60;
        }
        //return default ttl
        return Innoswift_Fpc_Model_Processor_Default::PAGE_CACHE_LIFE_TIME;
    }

    public function getUrlDepth() {
        $depth = trim(Mage::getStoreConfig('page_cache_fpc/settings/cache_url_depth'));

        if (!$depth || !is_numeric($depth)) {
            //default url depth
            return Innoswift_Fpc_Model_Processor_Default::URL_DEPTH_TO_CACHE;
        }

        $depth = intval($depth);
        if ($depth) {
            return $depth;
        }
    }

}