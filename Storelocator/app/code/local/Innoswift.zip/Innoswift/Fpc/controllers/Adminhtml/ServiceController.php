<?php

class Innoswift_Fpc_Adminhtml_ServiceController extends Mage_Adminhtml_Controller_action {

    public function gencacheAction() {
        
        $crawler = new Innoswift_Fpc_Model_Crawler();
        $crawler->crawl($this->getRequest()->get('uncached'));
    }

    public function getprogressAction() {

        $totalRecords = mage::getModel('innoswiftfpc/url')->getCollection()->getSize();
        
        $urlCollection = mage::getModel('innoswiftfpc/url')->getCollection();
        $urlCollection->addFieldToFilter('crawler_flag', 1);
        $_flaggedUrl = false;
        
        foreach ($urlCollection as $_flaggedUrl) {   
        }
        $urlsLeft=0;
        if ($_flaggedUrl) {
            //this means crawler was stopped in the middle
            $urlsToCache = mage::getModel('innoswiftfpc/url')->getCollection();
            $urlsToCache->addFieldToFilter('id', array('gteq' => $_flaggedUrl->getId()));
            $urlsLeft = $urlsToCache->getSize();
        }
        
        $utlsFinished = ($totalRecords-$urlsLeft);
        $percentageProgress = $utlsFinished/$totalRecords;
        $pixelWidth = Innoswift_Fpc_Block_Adminhtml_Crawler::PROGRESS_WIDTH;
        
        $response = new stdClass();
        $response->progress_width = intval($pixelWidth*$percentageProgress);
        $response->urls_left = $urlsLeft;
        echo json_encode($response);
        
    }

}