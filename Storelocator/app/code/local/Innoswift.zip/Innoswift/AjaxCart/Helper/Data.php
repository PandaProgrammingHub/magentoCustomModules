<?php


class Innoswift_AjaxCart_Helper_Data extends Mage_Core_Helper_Abstract
{
	/**
	 * get_add_url
	 * @return string "add to cart" url 
	 */
    public function get_add_url() {
    	return $this->_getUrl('ajaxcart/cart/add');
    }
    
	/**
	 * get_info_url()
	 * @return string url to get info after successfully add to cart
	 */
    public function get_info_url() {
    	return $this->_getUrl('ajaxcart/cart/getinfo');
    }
    /**
     *get_cart_url
     */
    public function get_cart_url(){
        return Mage::helper('checkout/cart')->getCartUrl();
        
    }
}