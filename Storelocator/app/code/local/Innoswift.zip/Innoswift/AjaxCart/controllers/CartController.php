<?php

class Innoswift_AjaxCart_CartController extends Mage_Core_Controller_Front_Action {

    protected function _get_cart() {
        return Mage::getSingleton('checkout/cart');
    }

    protected function _get_session() {
        return Mage::getSingleton('checkout/session');
    }

    protected function _init_product() {
        $productId = (int) $this->getRequest()->getParam('product');
        if ($productId) {
            $product = Mage::getModel('catalog/product')
                    ->setStoreId(Mage::app()->getStore()->getId())
                    ->load($productId);
            if ($product->getId()) {
                return $product;
            }
        }
        return false;
    }

    /**
     * Get the Count of Items in the shopping cart
     */
    private function _get_items_count() {
        $_items = $this->_get_session()->getQuote()->getAllItems();
        $_count = 0;
        foreach ($_items as $_item) {
            $_count += $_item->getQty();
        }
        return $_count;
    }

    private function _get_top_link($_count) {
        if ($_count == 0) {
            return Mage::helper('ajaxcart')->__('My Cart');
        } elseif ($_count == 1) {
            return Mage::helper('ajaxcart')->__('My Cart (%s item)', $_count);
        } else {
            return Mage::helper('ajaxcart')->__('My Cart (%s items)', $_count);
        }
    }

    private function _prepare_message_array($_success, $_message=null, $_data) {
        
        $_messagesHtml = $this->getLayout()->getMessagesBlock(
                )->setMessages($this->_get_session()->getMessages())->getGroupedHtml();
        $this->_get_session()->unsMessages();
        return array(
            'success' => $_success,
            'message' => $_messagesHtml,
            'data' => $_data,
        );
    }

    /**
     * Add Product Into Cart
     */
    public function addAction() {
        try {
            $cart = $this->_get_cart();
            $params = $this->getRequest()->getParams();
            $product = $this->_init_product();

            if (!$product) {
                $this->_get_session()->addError('Product is missing.');
                return false;
            }

            $cart->addProduct($product, $params);

            $cart->save();
            $this->_get_session()->setCartWasUpdated(true);
            $this->_get_session()->addSuccess("You have added <span id=dialog-pro-name>".$product->getName()."</span> into shopping cart.");
        } catch (Exception $e) {
            
            $this->_get_session()->addError(str_replace($product['name'], "<span id=dialog-pro-name>" . $product['name'] . "</span>", $e->getMessage()));
           
        }


        $this->getResponse()->setBody(
                json_encode($this->_prepare_message_array(True,null, null))
        );
        return true;
    }

    /**
     * 
     * After add to cart action, get the info for the added products
     */
    public function getinfoAction() {
        $_count = $this->_get_items_count();
        $_data = array(
            'count' => $_count,
            'toplink' => $this->_get_top_link($_count),
        );

        $this->getResponse()->setBody(json_encode(
                        $this->_prepare_message_array(true, '', $_data)
                ));

        return true;
    }
}
