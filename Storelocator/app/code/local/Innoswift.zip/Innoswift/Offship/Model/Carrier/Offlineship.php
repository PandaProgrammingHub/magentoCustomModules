<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Method
 *
 * @author shashi
 */
class Innoswift_Offship_Model_Carrier_Offlineship extends Mage_Shipping_Model_Carrier_Freeshipping implements Mage_Shipping_Model_Carrier_Interface {

    protected $_code = 'offlineshipping';

    /**
     * FreeShipping Rates Collector
     *
     * @param Mage_Shipping_Model_Rate_Request $request
     * @return Mage_Shipping_Model_Rate_Result
     */
    public function collectRates(Mage_Shipping_Model_Rate_Request $request) {
        if (!$this->getConfigFlag('active')) {
            return false;
        }

        $_grpId = Mage::getSingleton('customer/session')->getCustomerGroupId();
        $_groupsForNet = mage::getStoreConfig("carriers/offlineshipping/customer_groups");
        $_groupsForNet = explode(',', $_groupsForNet);

        //if he is admin we show ths method any way irrespective of customer group
        if (!Mage::getSingleton('admin/session')->isLoggedIn()) {

            if (!in_array($_grpId, $_groupsForNet)) {
                return false;
            }
        }


        $result = Mage::getModel('shipping/rate_result');
        $packageValue = $request->getPackageValue();

        $this->_updateFreeMethodQuote($request);

        $allow = true;

        if ($allow) {
            $method = Mage::getModel('shipping/rate_result_method');

            $method->setCarrier('offlineshipping');
            $method->setCarrierTitle($this->getConfigData('title'));

            $method->setMethod('offlineshipping');
            $method->setMethodTitle($this->getConfigData('name'));

            $method->setPrice('0.00');
            $method->setCost('0.00');

            $result->append($method);
        }

        return $result;
    }

    public function getAllowedMethods() {
        return array('offlineshipping' => $this->getConfigData('name'));
    }

}

