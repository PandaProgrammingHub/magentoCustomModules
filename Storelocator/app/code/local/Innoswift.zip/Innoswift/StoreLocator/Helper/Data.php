<?php

/**
 * Description of Data
 *
 * @author prasad
 */
class Innoswift_StoreLocator_Helper_Data extends Mage_Core_Helper_Abstract {

    function getStorelocatorUrl() {
        return $this->_getUrl('storelocator');
    }

}

