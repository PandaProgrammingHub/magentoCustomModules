<?php

class Innoswift_Terms_IndexController extends Mage_Core_Controller_Front_Action {

    public function indexAction() {

        $this->loadLayout();
        $this->_initLayoutMessages('customer/session');
        $this->renderLayout();
    }

    public function postAction() {
        $post = $this->getRequest()->getPost();
        try {
            if (empty($post)) {
                Mage::throwException($this->__('Invalid form data.'));
            }

            /* set general form data */
            $_netterm = Mage::getModel('netterms/terms')->setData($post);

            /* set customer id */
            $_netterm->setCustomer_id(Mage::getSingleton('customer/session')->getCustomerId());

            /* set status to Open (2) */
            $_netterm->setStatus(2);

            /* set status to Open (2) */
            $_netterm->setCreatedTime(now());

            $_netterm->save();
            //send email
            $_customer = Mage::getSingleton('customer/session')->getCustomer();
            $emailTemplate = Mage::getModel('core/email_template');
            $emailTemplate->setTemplateSubject("Net 30 Form submitted by:".$_customer->getFirstname()." ". $_customer->getLastname());

            $emailTemplate->setSenderName("Olovem Server");

            $emailTemplate->setSenderEmail("server@olovesm.com");
            $_toEmail = Mage::getStoreConfig('contacts/email/recipient_email');

            $emailTemplate->send($_toEmail);

            $message = $this->__('Your Application has been submitted successfully.');
            Mage::getSingleton('customer/session')->addSuccess($message);
        } catch (Exception $e) {
            Mage::getSingleton('customer/session')->addError($e->getMessage());
        }
        $this->_redirect('*/*');
    }

    /**
     * Action predispatch
     *
     * Check customer authentication for all actions
     */
    public function preDispatch() {

        parent::preDispatch();

        if (!$this->getRequest()->isDispatched()) {
            return;
        }
        $action = $this->getRequest()->getActionName();
        if (!$this->_getSession()->authenticate($this)) {
            $this->setFlag('', 'no-dispatch', true);
            return;
        }
    }

    /**
     * Retrieve customer session model object
     *
     * @return Mage_Customer_Model_Session
     */
    protected function _getSession() {
        return Mage::getSingleton('customer/session');
    }

}