<?php

class Innoswift_Terms_Block_Adminhtml_Terms_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form {

    protected function _prepareForm() {
        $form = new Varien_Data_Form();
        $this->setForm($form);
        $fieldset = $form->addFieldset('netterms_status', array('legend' => Mage::helper('netterms')->__('Status')));

        $fieldset->addField('status', 'select', array(
            'label' => Mage::helper('netterms')->__('Status'),
            'name' => 'status',
            'values' => array(
                array(
                    'value' => 1,
                    'label' => Mage::helper('netterms')->__('Denied'),
                ),
                array(
                    'value' => 2,
                    'label' => Mage::helper('netterms')->__('Open'),
                ),
                array(
                    'value' => 3,
                    'label' => Mage::helper('netterms')->__('Approved'),
                ),
            ),
        ));

        $fieldset = $form->addFieldset('netterms_business', array('legend' => Mage::helper('netterms')->__('Business Information')));


        $fieldset->addField('business_name', 'text', array(
            'label' => Mage::helper('netterms')->__('Business Name'),
            'class' => 'required-entry',
            'required' => true,
            'name' => 'business_name',
        ));

        $fieldset->addField('business_type', 'text', array(
            'label' => Mage::helper('netterms')->__('Business Type'),
            'class' => 'required-entry',
            'required' => true,
            'name' => 'business_type',
        ));

        $fieldset->addField('contact_name', 'text', array(
            'label' => Mage::helper('netterms')->__('Contact Name'),
            'class' => 'required-entry',
            'required' => true,
            'name' => 'contact_name',
        ));

        $fieldset->addField('contact_phone', 'text', array(
            'label' => Mage::helper('netterms')->__('Contact Phone'),
            'class' => 'required-entry',
            'required' => true,
            'name' => 'contact_phone',
        ));

        $fieldset->addField('contact_fax', 'text', array(
            'label' => Mage::helper('netterms')->__('Contact Fax'),
            'class' => 'required-entry',
            'required' => false,
            'name' => 'contact_fax',
        ));

        $fieldset->addField('contact_email', 'text', array(
            'label' => Mage::helper('netterms')->__('Contact Email'),
            'class' => 'required-entry',
            'required' => true,
            'name' => 'contact_email',
        ));

        $fieldset->addField('yrs_at_location', 'text', array(
            'label' => Mage::helper('netterms')->__('Years at location'),
            'class' => 'required-entry',
            'required' => true,
            'name' => 'yrs_at_location',
        ));

        $fieldset->addField('business_entity_type', 'select', array(
            'label' => Mage::helper('netterms')->__('Business Entity Type'),
            'name' => 'business_entity_type',
            'values' => array(
                array(
                    'value' => 'Corporation',
                    'label' => 'Corporation',
                ),
                array(
                    'value' => 'Partnership',
                    'label' => 'Partnership',
                ),
                array(
                    'value' => 'Sole Proprietorship',
                    'label' => 'Sole Proprietorship',
                ),
            ),
        ));

        $fieldset->addField('year_established', 'text', array(
            'label' => Mage::helper('netterms')->__('Year Established'),
            'class' => 'required-entry',
            'required' => true,
            'name' => 'year_established',
        ));

        $fieldset->addField('tax_id', 'text', array(
            'label' => Mage::helper('netterms')->__('Federal Tax Id'),
            'class' => 'required-entry',
            'required' => false,
            'name' => 'tax_id',
        ));

//        $fieldset->addField('duns_id', 'text', array(
//            'label' => Mage::helper('netterms')->__('Duns Id'),
//            'class' => '',
//            'required' => false,
//            'name' => 'duns_id',
//        ));

//        $fieldset->addField('principal_1', 'text', array(
//            'label' => Mage::helper('netterms')->__('Principal (Name of Officer or Owner)'),
//            'class' => 'required-entry',
//            'required' => true,
//            'name' => 'principal_1',
//        ));
//
//        $fieldset->addField('principal_2', 'text', array(
//            'label' => Mage::helper('netterms')->__('Principal (Name of Officer or Owner)'),
//            'class' => '',
//            'required' => false,
//            'name' => 'principal_2',
//        ));
//
//        $fieldset->addField('principal_3', 'text', array(
//            'label' => Mage::helper('netterms')->__('Principal (Name of Officer or Owner)'),
//            'class' => '',
//            'required' => false,
//            'name' => 'principal_3',
//        ));
//
//        $fieldset->addField('principal_4', 'text', array(
//            'label' => Mage::helper('netterms')->__('Principal (Name of Officer or Owner)'),
//            'class' => '',
//            'required' => false,
//            'name' => 'principal_4',
//        ));
//
//        $fieldset->addField('buyer_name', 'text', array(
//            'label' => Mage::helper('netterms')->__('Buyer Name (Who will be purchasing?)'),
//            'class' => 'required-entry',
//            'required' => true,
//            'name' => 'buyer_name',
//        ));

        $fieldset = $form->addFieldset('netterms_ap', array('legend' => Mage::helper('netterms')->__('Accounts Payable Information')));

        $fieldset->addField('ap_contact_name', 'text', array(
            'label' => Mage::helper('netterms')->__('Account Payable Contact Name'),
            'class' => 'required-entry',
            'required' => false,
            'name' => 'ap_contact_name',
        ));

        $fieldset->addField('ap_contact_phone', 'text', array(
            'label' => Mage::helper('netterms')->__('Account Payable Contact Phone'),
            'class' => 'required-entry',
            'required' => false,
            'name' => 'ap_contact_phone',
        ));

        $fieldset->addField('ap_contact_email', 'text', array(
            'label' => Mage::helper('netterms')->__('Account Payable Contact Email'),
            'class' => 'required-entry',
            'required' => false,
            'name' => 'ap_contact_email',
        ));

        $fieldset = $form->addFieldset('netterms_referrals', array('legend' => Mage::helper('netterms')->__('Referral Information')));

        $fieldset->addField('referral_1_business_name', 'text', array(
            'label' => Mage::helper('netterms')->__('Referral 1 Business Name'),
            'class' => 'required-entry',
            'required' => false,
            'name' => 'referral_1_business_name',
        ));

        $fieldset->addField('referral_1_ap_name', 'text', array(
            'label' => Mage::helper('netterms')->__('Referral 1 A/P Contact Name'),
            'class' => 'required-entry',
            'required' => false,
            'name' => 'referral_1_ap_name',
        ));

        $fieldset->addField('referral_1_ap_phone', 'text', array(
            'label' => Mage::helper('netterms')->__('Referral 1 A/P Contact Phone'),
            'class' => 'required-entry',
            'required' => false,
            'name' => 'referral_1_ap_phone',
        ));

        $fieldset->addField('referral_1_ap_email', 'text', array(
            'label' => Mage::helper('netterms')->__('Referral 1 A/P Contact Email'),
            'class' => 'required-entry',
            'required' => false,
            'name' => 'referral_1_ap_email',
        ));

//        $fieldset->addField('referral_2_business_name', 'text', array(
//            'label' => Mage::helper('netterms')->__('Referral 2 Business Name'),
//            'class' => 'required-entry',
//            'required' => true,
//            'name' => 'referral_2_business_name',
//        ));
//
//        $fieldset->addField('referral_2_ap_name', 'text', array(
//            'label' => Mage::helper('netterms')->__('Referral 2 A/P Contact Name'),
//            'class' => 'required-entry',
//            'required' => true,
//            'name' => 'referral_2_ap_name',
//        ));
//
//        $fieldset->addField('referral_2_ap_phone', 'text', array(
//            'label' => Mage::helper('netterms')->__('Referral 2 A/P Contact Phone'),
//            'class' => 'required-entry',
//            'required' => true,
//            'name' => 'referral_2_ap_phone',
//        ));
//
//        $fieldset->addField('referral_2_ap_email', 'text', array(
//            'label' => Mage::helper('netterms')->__('Referral 2 A/P Contact Email'),
//            'class' => 'required-entry',
//            'required' => true,
//            'name' => 'referral_2_ap_email',
//        ));
//
//        $fieldset->addField('referral_3_business_name', 'text', array(
//            'label' => Mage::helper('netterms')->__('Referral 3 Business Name'),
//            'class' => 'required-entry',
//            'required' => true,
//            'name' => 'referral_3_business_name',
//        ));
//
//        $fieldset->addField('referral_3_ap_name', 'text', array(
//            'label' => Mage::helper('netterms')->__('Referral 3 A/P Contact Name'),
//            'class' => 'required-entry',
//            'required' => true,
//            'name' => 'referral_3_ap_name',
//        ));
//
//        $fieldset->addField('referral_3_ap_phone', 'text', array(
//            'label' => Mage::helper('netterms')->__('Referral 3 A/P Contact Phone'),
//            'class' => 'required-entry',
//            'required' => true,
//            'name' => 'referral_3_ap_phone',
//        ));
//
//        $fieldset->addField('referral_3_ap_email', 'text', array(
//            'label' => Mage::helper('netterms')->__('Referral 3 A/P Contact Email'),
//            'class' => 'required-entry',
//            'required' => true,
//            'name' => 'referral_3_ap_email',
//        ));

//        $fieldset = $form->addFieldset('netterms_bank', array('legend' => Mage::helper('netterms')->__('Bank Information')));
//
//        $fieldset->addField('bank_name', 'text', array(
//            'label' => Mage::helper('netterms')->__('Bank Name'),
//            'class' => 'required-entry',
//            'required' => true,
//            'name' => 'bank_name',
//        ));
//
//        $fieldset->addField('bank_address', 'text', array(
//            'label' => Mage::helper('netterms')->__('Bank Address'),
//            'class' => 'required-entry',
//            'required' => true,
//            'name' => 'bank_address',
//        ));
//
//        $fieldset->addField('bank_contact_name', 'text', array(
//            'label' => Mage::helper('netterms')->__('Bank Contact Name'),
//            'class' => 'required-entry',
//            'required' => true,
//            'name' => 'bank_contact_name',
//        ));
//
//        $fieldset->addField('bank_contact_phone', 'text', array(
//            'label' => Mage::helper('netterms')->__('Bank Contact Phone'),
//            'class' => 'required-entry',
//            'required' => true,
//            'name' => 'bank_contact_phone',
//        ));


        if (Mage::getSingleton('adminhtml/session')->getnettermsData()) {
            $form->setValues(Mage::getSingleton('adminhtml/session')->getnettermsData());
            Mage::getSingleton('adminhtml/session')->setnettermsData(null);
        } elseif (Mage::registry('netterms_data')) {
            $form->setValues(Mage::registry('netterms_data')->getData());
        }
        return parent::_prepareForm();
    }

}