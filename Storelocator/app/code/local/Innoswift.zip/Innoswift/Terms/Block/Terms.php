<?php

class Innoswift_Terms_Block_Terms extends Mage_Customer_Block_Account_Dashboard {

    protected $_netterm;

    public function _prepareLayout() {
        return parent::_prepareLayout();
    }

    public function getTerms() {
        if (!$this->hasData('netterms')) {
            $this->setData('netterms', Mage::registry('netterms'));
        }
        return $this->getData('netterms');
    }

    public function getTermsByCustomer() {
        $customerId = Mage::getSingleton('customer/session')->getCustomerId();

        $netterms = Mage::getModel('netterms/terms')->load($customerId, 'customer_id');
        
        $this->_netterm = $netterms;

        return $this->_netterm;
    }

}