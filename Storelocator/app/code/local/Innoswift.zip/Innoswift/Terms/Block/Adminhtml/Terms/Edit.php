<?php

class Innoswift_Terms_Block_Adminhtml_Terms_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                 
        $this->_objectId = 'id';
        $this->_blockGroup = 'netterms';
        $this->_controller = 'adminhtml_terms';
        
        $this->_updateButton('save', 'label', Mage::helper('netterms')->__('Save Application'));
        $this->_updateButton('delete', 'label', Mage::helper('netterms')->__('Delete Application'));
		
        $this->_addButton('saveandcontinue', array(
            'label'     => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);

        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('netterms_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'netterms_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'netterms_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    public function getHeaderText()
    {
        if( Mage::registry('netterms_data') && Mage::registry('netterms_data')->getId() ) {
            return Mage::helper('netterms')->__("Edit Application for '%s'", $this->htmlEscape(Mage::registry('netterms_data')->getBusinessName()));
        } else {
            return Mage::helper('netterms')->__('Add New Application');
        }
    }
}