<?php
class Innoswift_Terms_Block_Adminhtml_Terms extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_terms';
    $this->_blockGroup = 'netterms';
    $this->_headerText = Mage::helper('netterms')->__('Net Terms Application Manager');
    //$this->_addButtonLabel = Mage::helper('netterms')->__('Add Application');
   
    parent::__construct();
     $this->removeButton("add");
  }
}