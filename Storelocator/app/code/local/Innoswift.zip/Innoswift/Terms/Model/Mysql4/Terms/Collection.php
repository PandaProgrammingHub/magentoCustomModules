<?php

class Innoswift_Terms_Model_Mysql4_Terms_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('netterms/terms');
    }
}