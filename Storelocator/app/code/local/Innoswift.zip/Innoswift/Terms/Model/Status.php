<?php

class Innoswift_Terms_Model_Status extends Varien_Object
{
    const STATUS_DENIED	= 1;
    const STATUS_OPEN	= 2;
    const STATUS_APPROVED	= 3;

    static public function getOptionArray()
    {
        return array(
            self::STATUS_DENIED    => Mage::helper('netterms')->__('Denied'),
            self::STATUS_OPEN   => Mage::helper('netterms')->__('Open'),
            self::STATUS_APPROVED	=> Mage::helper('netterms')->__('Approved')
        );
    }
}