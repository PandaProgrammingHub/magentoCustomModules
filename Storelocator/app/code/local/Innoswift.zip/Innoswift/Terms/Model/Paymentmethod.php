<?php

class Innoswift_Terms_Model_Paymentmethod extends Mage_Payment_Model_Method_Purchaseorder {

    protected $_code = 'net30';
    protected $_canUseCheckout = true;
    protected $_canUseInternal = true;
    protected $_canUseForMultishipping = true;

    public function isAvailable($quote=null) {

        $_grpId = Mage::getSingleton('customer/session')->getCustomerGroupId();
        $_groupsForNet = mage::getStoreConfig("payment/net30/customer_groups");
        $_groupsForNet =explode(',', $_groupsForNet);

        //if he is admin we show ths method any way
        if (!Mage::getSingleton('admin/session')->isLoggedIn()) {
            if (!in_array($_grpId, $_groupsForNet)) {
                return false;
            }
        }
        return true;
    }

}