<?php

class Innoswift_Terms_Model_Terms extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('netterms/terms');
    }
    
        
}