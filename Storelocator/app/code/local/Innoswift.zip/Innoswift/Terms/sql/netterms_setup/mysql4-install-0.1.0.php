<?php

$installer = $this;

$installer->startSetup();

$installer->run("
-- DROP TABLE IF EXISTS `{$this->getTable('netterms')}`;
CREATE TABLE `{$this->getTable('netterms')}` (
  `netterms_id` int(11) unsigned NOT NULL auto_increment,
  `customer_id` int(10) unsigned NOT NULL default '0',
  `business_name` varchar(255) NOT NULL default '',
  `business_type` varchar(255) NOT NULL default '',
  `contact_name` varchar(255) NOT NULL default '',
  `contact_phone` varchar(12) NOT NULL default '',
  `contact_fax` varchar(255) NOT NULL default '',
  `contact_email` varchar(255) NOT NULL default '',
  `yrs_at_location` varchar(255) NOT NULL default '',
  `business_entity_type` varchar(255) NOT NULL default '',
  `year_established` varchar(4) NOT NULL default '',
  `tax_id` varchar(255) NOT NULL default '',
  `duns_id` varchar(255) NOT NULL default '',
  `principal_1` varchar(255) NOT NULL default '',
  `principal_2` varchar(255) default '',
  `principal_3` varchar(255) default '',
  `principal_4` varchar(255) default '',
  `buyer_name` varchar(255) NOT NULL default '',
  `ap_contact_name` varchar(255) NOT NULL default '',
  `ap_contact_phone` varchar(12) NOT NULL default '',
  `ap_contact_email` varchar(255) NOT NULL default '',
  `referral_1_business_name` varchar(255) NOT NULL default '',
  `referral_1_ap_name` varchar(255) NOT NULL default '',
  `referral_1_ap_phone` varchar(12) NOT NULL default '',
  `referral_1_ap_email` varchar(255) NOT NULL default '',
  `referral_2_business_name` varchar(255) NOT NULL default '',
  `referral_2_ap_name` varchar(255) NOT NULL default '',
  `referral_2_ap_phone` varchar(12) NOT NULL default '',
  `referral_2_ap_email` varchar(255) NOT NULL default '',
  `referral_3_business_name` varchar(255) NOT NULL default '',
  `referral_3_ap_name` varchar(255) NOT NULL default '',
  `referral_3_ap_phone` varchar(12) NOT NULL default '',
  `referral_3_ap_email` varchar(255) NOT NULL default '',
  `bank_name` varchar(255) NOT NULL default '',
  `bank_address` varchar(255) NOT NULL default '',
  `bank_contact_name` varchar(255) NOT NULL default '',
  `bank_contact_phone` varchar(12) NOT NULL default '',
  `status` smallint(6) NOT NULL default '1',
  `created_time` datetime NULL,
  `update_time` datetime NULL,
  PRIMARY KEY (`netterms_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

    ");

$installer->endSetup(); 