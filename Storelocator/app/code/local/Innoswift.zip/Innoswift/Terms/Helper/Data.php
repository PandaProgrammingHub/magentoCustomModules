<?php

class Innoswift_Terms_Helper_Data extends Mage_Core_Helper_Abstract {
     
    
    
    public function isWholesaleOnlyProduct($product) {
        $_groupId = Mage::getSingleton('customer/session')->getCustomerGroupId();
        $_categoryIds = $product->getCategoryIds();
        if($_groupId!=2 && in_array(86,$_categoryIds)){
            return true;
        }else{
            return false;
        }
    }

}