<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Newarrivals
 *
 * @author shashi
 */
class Innoswift_Customer_Block_Newarrivals extends Mage_Catalog_Block_Product_Abstract{
    //put your code here
}

